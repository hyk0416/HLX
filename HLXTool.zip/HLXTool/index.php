<!DOCTYPE html>
<html lang="zh">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>昔日轮回 - HLX Tool</title>
    <link rel="icon" href="favicon.ico" type="image/ico">
    <meta name="author" content="XRLH">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/materialdesignicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="js/bootstrap-multitabs/multitabs.min.css">
    <link href="css/style.min.css" rel="stylesheet">
    <!--统计-->
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?17286e0caaa291c12ce45e320c4131d2";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>


    <style>
        /*头像呼吸光环和鼠标悬停旋转放大*/
        .img-avatar {
            border-radius: 50%;
            animation: light 4s ease-in-out infinite;
            transition: 0.5s;
        }

        .img-avatar:hover {
            transform: scale(1.15) rotate(720deg);
        }

        @keyframes light {
            0% {
                box-shadow: 0 0 4px #f00;
            }

            25% {
                box-shadow: 0 0 16px #0f0;
            }

            50% {
                box-shadow: 0 0 4px #00f;
            }

            75% {
                box-shadow: 0 0 16px #0f0;
            }

            100% {
                box-shadow: 0 0 4px #f00;
            }
        }
    </style>
</head>

<body>
    <div class="lyear-layout-web">
        <div class="lyear-layout-container">
            <!--左侧导航-->
            <aside class="lyear-layout-sidebar">

                <!-- logo -->
                <div id="logo" class="sidebar-header">
                    <a href="index.html"><img src="images/logo.png" title="LightYear" alt="LightYear" /></a>
                </div>
                <div class="lyear-layout-sidebar-scroll">

                    <nav class="sidebar-main">
                        <ul class="nav nav-drawer">
                            <li class="nav-item"><a class="multitabs" href="collection.html"><i class="mdi mdi-home"></i> <span>获取收藏列表</span></a></li>
                            <li class="nav-item"><a class="multitabs" href="start.html"><i class="mdi mdi-palette"></i>
                                    <span>获取关注列表</span></a></li>
                            <li class="nav-item active"> <a class="multitabs" href="postid.html"><i class="mdi mdi-star"></i> <span>获取帖子ID</span></a> </li>
                            <li class="nav-item nav-item-has-subnav">
                                <a href="javascript:void(0)"><i class="mdi mdi-format-align-justify"></i>
                                    <span>跳转功能(葫芦侠APP内有效)</span></a>
                                <ul class="nav nav-subnav">
                                    <li> <a class="multitabs" href="go_user.html">用户</a> </li>
                                    <li> <a class="multitabs" href="go_post.html">主题</a> </li>
                                    <li> <a class="multitabs" href="go_app.html">软件</a> </li>
                                </ul>
                            </li>


                        </ul>
                    </nav>

                    <div class="sidebar-footer">
                        <p class="copyright">Copyright &copy; 2022. All rights By <a href="http://www.hyk416.cn" target="_blank">XRLH</a>.</p>
                       
                    </div>

                </div>

            </aside>
            <!--End 左侧导航-->

            <!--头部信息-->
            <header class="lyear-layout-header">

                <nav class="navbar navbar-default">
                    <div class="topbar">

                        <div class="topbar-left">
                            <div class="lyear-aside-toggler">
                                <span class="lyear-toggler-bar"></span>
                                <span class="lyear-toggler-bar"></span>
                                <span class="lyear-toggler-bar"></span>
                            </div>
                        </div>
                        
                        <!--访问量-->
                         <?php
                        if (!file_exists("count.txt")) {
                            $one_file = fopen("count.txt", "w+"); //建立一个统计文本，如果不存在就创建
                            echo "您是第<font color='red'><b>1</b></font>位使用者"; //首次直接输出第一次
                            fwrite("count.txt", "1");  //把数字1写入文本
                            fclose("$one_file");
                        } else { //如果不是第一次访问直接读取内容，并+1,写入更新后再显示新的访客数
                            $num = file_get_contents("count.txt");
                            $num++;
                            file_put_contents("count.txt", "$num");
                            $newnum = file_get_contents("count.txt");
                            echo "您是第<font color='red'><b>" . $newnum . "</b></font>位使用者";
                        }
                        ?>
                        
                        
                        <ul class="topbar-right">
                            <li class="dropdown dropdown-profile">
                                <a href="javascript:void(0)" data-toggle="dropdown">
                                    <img class="img-avatar img-avatar-48 m-r-10" src="./images/1.png" alt="昔日轮回" />
                                    <span>昔日轮回 <span class="caret"></span></span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li> <a href="javascript:void(0)" onclick="uid(981570)"><i class="mdi mdi-account"></i> 个人信息</a> </li>
                                </ul>
                            </li>
                            <!--切换主题配色-->
                            <li class="dropdown dropdown-skin">
                                <span data-toggle="dropdown" class="icon-palette"><i class="mdi mdi-palette"></i></span>
                                <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                                    <li class="drop-title">
                                        <p>LOGO</p>
                                    </li>
                                    <li class="drop-skin-li clearfix">
                                        <span class="inverse">
                                            <input type="radio" name="logo_bg" value="default" id="logo_bg_1" checked>
                                            <label for="logo_bg_1"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_2" id="logo_bg_2">
                                            <label for="logo_bg_2"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_3" id="logo_bg_3">
                                            <label for="logo_bg_3"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_4" id="logo_bg_4">
                                            <label for="logo_bg_4"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_5" id="logo_bg_5">
                                            <label for="logo_bg_5"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_6" id="logo_bg_6">
                                            <label for="logo_bg_6"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_7" id="logo_bg_7">
                                            <label for="logo_bg_7"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="logo_bg" value="color_8" id="logo_bg_8">
                                            <label for="logo_bg_8"></label>
                                        </span>
                                    </li>
                                    <li class="drop-title">
                                        <p>头部</p>
                                    </li>
                                    <li class="drop-skin-li clearfix">
                                        <span class="inverse">
                                            <input type="radio" name="header_bg" value="default" id="header_bg_1" checked>
                                            <label for="header_bg_1"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_2" id="header_bg_2">
                                            <label for="header_bg_2"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_3" id="header_bg_3">
                                            <label for="header_bg_3"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_4" id="header_bg_4">
                                            <label for="header_bg_4"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_5" id="header_bg_5">
                                            <label for="header_bg_5"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_6" id="header_bg_6">
                                            <label for="header_bg_6"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_7" id="header_bg_7">
                                            <label for="header_bg_7"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="header_bg" value="color_8" id="header_bg_8">
                                            <label for="header_bg_8"></label>
                                        </span>
                                    </li>
                                    <li class="drop-title">
                                        <p>侧边栏</p>
                                    </li>
                                    <li class="drop-skin-li clearfix">
                                        <span class="inverse">
                                            <input type="radio" name="sidebar_bg" value="default" id="sidebar_bg_1" checked>
                                            <label for="sidebar_bg_1"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_2" id="sidebar_bg_2">
                                            <label for="sidebar_bg_2"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_3" id="sidebar_bg_3">
                                            <label for="sidebar_bg_3"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_4" id="sidebar_bg_4">
                                            <label for="sidebar_bg_4"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_5" id="sidebar_bg_5">
                                            <label for="sidebar_bg_5"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_6" id="sidebar_bg_6">
                                            <label for="sidebar_bg_6"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_7" id="sidebar_bg_7">
                                            <label for="sidebar_bg_7"></label>
                                        </span>
                                        <span>
                                            <input type="radio" name="sidebar_bg" value="color_8" id="sidebar_bg_8">
                                            <label for="sidebar_bg_8"></label>
                                        </span>
                                    </li>
                                </ul>
                            </li>
                            <!--切换主题配色-->
                        </ul>

                    </div>
                </nav>

            </header>
            <!--End 头部信息-->

            <!--页面主要内容-->
            <main class="lyear-layout-content">

                <div id="iframe-content"></div>

            </main>
            <!--End 页面主要内容-->
        </div>
    </div>

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/perfect-scrollbar.min.js"></script>
    <script type="text/javascript" src="js/bootstrap-multitabs/multitabs.js"></script>
    <script type="text/javascript" src="js/index.min.js"></script>
    <script src="js/inde.js" type="text/javascript" charset="utf-8"></script>
    <script async src="//busuanzi.ibruce.info/busuanzi/2.3/busuanai.pure.mini.jis "></script>

</body>

</html>